# Persistent Storage Benchmark Tests

These tests are based upon the [linux fio](https://github.com/axboe/fio) and [ioping](https://github.com/koct9i/ioping) utilities. These utilities can be used to benchmark the performance and latency of persistent storage volumes.  

*- Be aware that these tests will attempt to drive the IOPS to the maximum value and thus should not be run in parallel with any application that is dependent upon the same persistent storage. -*

The files included in the archive are as follows:

### runperf.sh

Entrypoint reference within the provided Dockerfile. It is used to trigger the execution of the fio and ioping utilities.  

### fiojobfile

This file contains the configuration data for the fio utility. It defines the tests to be run.
As supplied, the file defines three independent tests. Each test measures the IOPS and bandwidth of a mixture of read/write operations (75% Read, 25% Write) using 4k, 16k and 64k block sizes.

These test definitions can be modified to more accurately represent your particular workload if desired.

### Dockerfile

A sample Dockerfile that can be used to build the test container image. It defines a simple Debian based image containing the fio and ioping packages and the above fiojobfile.

###### Building
The image should be built and published to a container registry. The example commands below demonstrate use of the IBM Cloud Container Registry.  
See https://console.bluemix.net/docs/services/Registry/index.html for further information.  
(It is assumed that the `IBM Cloud CLI` and `IBM Cloud Container Registry plugin` have been installed previously)

From the directory containing the extracted files, substituting <region\> and <my_namespace\> with values appropriate for your environment, issue the following commands:
```
# Build the docker image
$ docker build -t registry.<region>.bluemix.net/<my_namespace>/psperf:latest -f Dockerfile .

# Login to IBM Cloud
$ ibmcloud login  

# Log the local Docker client in to IBM Cloud Container Registry.
$ ibmcloud cr login  

# Push the docker image to your container registry namespace
$ docker push registry.<region>.bluemix.net/<my_namespace>/psperf:latest
```

### pvc.yaml

If you are not benchmarking an existing persistent storage volume, then this PersistentVolumeClaim can be used to request persistent storage. This sample file defines a 200GB persistent volume with a "silver" block storage class. Modify to match your requirements.   

Note: If the testing is to be performed against block storage, then the IBM Block Storage plugin must be installed (using Helm) first.
```
$ helm repo update
$ helm install ibm/ibmcloud-block-storage-plugin
```
See https://console.bluemix.net/docs/containers/cs_storage_block.html#block_storage for further details

To begin the provisioning of the persistent storage:
```
$ kubectl apply -f pvc.yaml
```
After the PVC is created, the storage device and the PV are automatically created for you. The status of the PVC and associated PV changes to Bound when complete.  
See https://console.bluemix.net/docs/containers/cs_storage_basics.html#kube_concepts for further details.  

### job.yaml

This is a sample Kubernetes job definition which can be used to run the tests.

You should modify the `image` definition to match the location of your published image - see Dockerfile - Building.

Additionally, if you are use a pre-existing persistent volume, then the `claimName` field should be modified accordingly.
```
$ kubectl apply -f job.yaml
```

## Output

Test results are written to stdout and can be obtained via the container logs.
```
$ kubectl logs job/perf-test-job
```

##### Example results
fio-2.2.10
Starting 1 process  
test: Laying out IO file(s) (1 file(s) / 2048MB)  
Jobs: 1 (f=1): [m(1)] [99.8% done] [2984KB/968KB/0KB /s] [746/242/0 iops] [eta 00m:01s]
test: (groupid=0, jobs=1): err= 0: pid=28: Mon May 21 09:54:07 2018  
  read : io=1535.7MB, bw=2458.4KB/s, `iops=614`, runt=639405msec  
  write: io=525248KB, bw=841178B/s, `iops=205`, runt=639405msec

Total iops achieved in the test can be calculated by summing the read/write iops above

--- ioping statistics ---  
100 requests completed in 1.65 min, 1.25 k iops, 4.90 MiB/s  
`min/avg/max/mdev = 588 us / 797 us / 1.41 ms / 127 us`
