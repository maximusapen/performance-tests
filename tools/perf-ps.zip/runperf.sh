#!/bin/bash -e
cd "${PVMOUNTDIR}"; fio /tmp/fiojobfile
ioping -c 100 "${PVMOUNTDIR}"
